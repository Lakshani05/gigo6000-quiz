import {createContext} from 'react';

const QuizContext = createContext();

export default QuizContext;
