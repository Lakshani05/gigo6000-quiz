# Quiz App

[![forthebadge](https://forthebadge.com/images/badges/fuck-it-ship-it.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/made-with-javascript.svg)](https://forthebadge.com)

<p align="center">
    <img src="https://i.imgur.com/NtxQwtR.gif">
</p>

This is a sample Quiz app using React Hooks (useReducer() + useContext()).

## Usage

If you want to use it on your local environment you can run:

`npm start`

It will run the app in development mode and it will open [http://localhost:3000](http://localhost:3000) in your browser.

## React Hooks Tutorial

This app was created for a React Hooks tutorial, if you want to follow the tutorial on Youtube go there: [https://youtube.com/CarlosMafla](https://youtube.com/CarlosMafla)

## Contributing

Pull requests are welcome.

## License

[MIT](https://choosealicense.com/licenses/mit/)
